console.log('current filepath: /watchface/balance/index.js');
try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const hmUI = __$$RQR$$__('@zos/ui');
                const utils = __$$RQR$$__('@zos/utils');
                const app = __$$RQR$$__('@zos/app');
                const sensor = __$$RQR$$__('@zos/sensor');
                const router = __$$RQR$$__('@zos/router');
                const i18n = __$$RQR$$__('@zos/i18n');
                const settings = __$$RQR$$__('@zos/settings');
                function _interopNamespaceCompat(e) {
                    if (e && typeof e === 'object' && 'default' in e)
                        return e;
                    const n = Object.create(null, { [Symbol.toStringTag]: { value: 'Module' } });
                    if (e) {
                        for (const k in e) {
                            if (k !== 'default') {
                                const d = Object.getOwnPropertyDescriptor(e, k);
                                Object.defineProperty(n, k, d.get ? d : {
                                    enumerable: true,
                                    get: () => e[k]
                                });
                            }
                        }
                    }
                    n.default = e;
                    return Object.freeze(n);
                }
                const hmUI__namespace = _interopNamespaceCompat(hmUI);
                try {
                    ((() => {
                        const logger = utils.log.getLogger('greenpler-watchface');
                        const img = utils.assets('images');
                        const font = utils.assets('fonts');
                        let font_file_text = '';
                        let font_file_number = '';
                        let text_size_config = {};
                        let timerId = null;
                        let useTimer = false;
                        let useInterval = false;
                        let normal_background_bg = '';
                        let idle_background_bg = '';
                        let battery = '';
                        let normal_battery_icon_img_out = '';
                        let normal_battery_icon_img_top = '';
                        let normal_battery_icon_img_inner = '';
                        let normal_battery_linear_scale = '';
                        let normal_battery_current_text_font = '';
                        let timeSensor = '';
                        let normal_time_hour_text_font = '';
                        let idle_time_hour_text_font = '';
                        let normal_time_minute_text_font = '';
                        let idle_time_minute_text_font = '';
                        let normal_time_second_text_font = '';
                        let normal_AM_PM_text_font = '';
                        let idle_AM_PM_text_font = '';
                        let normal_day_text_font = '';
                        let normal_week_text_font = '';
                        let normal_WEEK_Array = [];
                        let normal_AM_Text = '';
                        let normal_PM_Text = '';
                        let Button_calendar = '';
                        let Button_battery = '';
                        let Button_countdown = '';
                        let Button_alarm = '';
                        let Button_hr = '';
                        let Button_steps = '';
                        let Button_sleep = '';
                        let Button_style = '';
                        let colorDialogWidgets = [];
                        let selectedTextColor = '0x00FF80';
                        const colorPalette = [
                            Number('0x00FF7F'),
                            Number('0x7FFFBF'),
                            Number('0x00FFFF'),
                            Number('0x7FFFFF'),
                            Number('0x007FFF'),
                            Number('0x7FBFFF'),
                            Number('0x0000FF'),
                            Number('0x7F7FFF'),
                            Number('0x7F00FF'),
                            Number('0xBF7FFF'),
                            Number('0xFF00FF'),
                            Number('0xFF7FFF'),
                            Number('0xFF007F'),
                            Number('0xFF7FBF'),
                            Number('0xFF0000'),
                            Number('0xFF7F7F'),
                            Number('0xFF7F00'),
                            Number('0xFFBF7F'),
                            Number('0xFFFF00'),
                            Number('0xFFFF7F'),
                            Number('0x7FFF00'),
                            Number('0xBFFF7F'),
                            Number('0x00FF00'),
                            Number('0x7FFF7F')
                        ];
                        __$$module$$__.module = WatchFace({
                            init_view() {
                                settingsLanguageConfig();
                                normal_background_bg = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 0,
                                    y: 0,
                                    w: 480,
                                    h: 480,
                                    color: '0x000000',
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_battery_icon_img_top = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 204,
                                    y: 428,
                                    w: 6,
                                    h: 4,
                                    color: '0x00FF88',
                                    radius: 2,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_battery_icon_img_out = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 200,
                                    y: 431,
                                    w: 14,
                                    h: 22,
                                    color: '0x00FF88',
                                    radius: 2,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_battery_icon_img_inner = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 202,
                                    y: 433,
                                    w: 10,
                                    h: 18,
                                    color: '0x000000',
                                    radius: 2,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_battery_linear_scale = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 201,
                                    y: 453,
                                    w: 12,
                                    h: 0,
                                    color: '0x00FF88',
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                battery = new sensor.Battery();
                                battery.onChange(batteryIconFillUpdate);
                                normal_battery_current_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT_FONT, {
                                    x: 220,
                                    y: 424,
                                    w: 100,
                                    h: 40,
                                    text_size: text_size_config.normal_battery_current_text_size,
                                    char_space: -2,
                                    font: font_file_number,
                                    color: '0xFFFFFF',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    unit_type: 1,
                                    type: hmUI__namespace.data_type.BATTERY,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                timeSensor = new sensor.Time();
                                timeSensor.onPerDay(dayUpdate);
                                timeSensor.onPerMinute(minuteUpdate);
                                timeSensor.onPerHourEnd(hourUpdate);
                                timeSensor.onPhoneTimeSetting(updateAllFonts);
                                normal_time_hour_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 44,
                                    y: 196,
                                    w: 200,
                                    h: 120,
                                    text_size: text_size_config.normal_time_hour_text_size,
                                    char_space: -8,
                                    font: font_file_number,
                                    color: '0xFFFFFDFB',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.RIGHT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_time_minute_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 236,
                                    y: 196,
                                    w: 200,
                                    h: 120,
                                    text_size: text_size_config.normal_time_minute_text_size,
                                    char_space: -8,
                                    font: font_file_number,
                                    color: '0x00FF88',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_time_second_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 400,
                                    y: 190,
                                    w: 60,
                                    h: 60,
                                    text_size: text_size_config.normal_time_second_text_size,
                                    char_space: -4,
                                    font: font_file_number,
                                    color: '0x808080',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.TOP,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_AM_PM_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 402,
                                    y: 232,
                                    w: 100,
                                    h: 100,
                                    text_size: text_size_config.normal_AM_PM_text_size,
                                    char_space: -2,
                                    font: font_file_text,
                                    color: '0x00FF88',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_day_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 176,
                                    y: 55,
                                    w: 50,
                                    h: 40,
                                    text_size: text_size_config.normal_day_text_size,
                                    char_space: 0,
                                    font: font_file_number,
                                    color: '0x00FF88',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.RIGHT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                normal_week_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 231,
                                    y: 55,
                                    w: 70,
                                    h: 40,
                                    text_size: text_size_config.normal_week_text_size,
                                    char_space: 0,
                                    font: font_file_text,
                                    color: '0xFFFFFF',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                idle_background_bg = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                    x: 0,
                                    y: 0,
                                    w: 480,
                                    h: 480,
                                    color: '0xFF000000',
                                    show_level: hmUI__namespace.show_level.ONLY_AOD
                                });
                                idle_AM_PM_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 402,
                                    y: 232,
                                    w: 100,
                                    h: 100,
                                    text_size: text_size_config.idle_AM_PM_text_size,
                                    char_space: -2,
                                    font: font_file_text,
                                    color: '0x00FF88',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_AOD
                                });
                                idle_time_hour_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 44,
                                    y: 196,
                                    w: 200,
                                    h: 120,
                                    text_size: text_size_config.idle_time_hour_text_size,
                                    char_space: -8,
                                    font: font_file_number,
                                    color: '0x484848',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.RIGHT,
                                    show_level: hmUI__namespace.show_level.ONLY_AOD
                                });
                                idle_time_minute_text_font = hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT, {
                                    x: 236,
                                    y: 196,
                                    w: 200,
                                    h: 120,
                                    text_size: text_size_config.idle_time_minute_text_size,
                                    char_space: -8,
                                    font: font_file_number,
                                    color: '0x00FF88',
                                    line_space: 0,
                                    align_v: hmUI__namespace.align.CENTER_V,
                                    text_style: hmUI__namespace.text_style.ELLIPSIS,
                                    align_h: hmUI__namespace.align.LEFT,
                                    show_level: hmUI__namespace.show_level.ONLY_AOD
                                });
                                Button_calendar = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 173,
                                    y: 45,
                                    w: 134,
                                    h: 60,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_CALENDAR,
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_battery = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 184,
                                    y: 416,
                                    w: 112,
                                    h: 60,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            url: 'Settings_batteryManagerScreen',
                                            native: true
                                        });
                                    },
                                    longpress_func: button_widget => {
                                        router.launchApp({
                                            url: 'LowBatteryScreen',
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_countdown = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 394,
                                    y: 184,
                                    w: 90,
                                    h: 112,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_COUNTDOWN,
                                            native: true
                                        });
                                    },
                                    longpress_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_STOPWATCH,
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_alarm = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 80,
                                    y: 184,
                                    w: 306,
                                    h: 112,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    longpress_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_ALARM,
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_hr = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 40,
                                    y: 40,
                                    w: 100,
                                    h: 100,
                                    radius: 50,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_HR,
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_steps = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 340,
                                    y: 40,
                                    w: 100,
                                    h: 100,
                                    radius: 50,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            url: 'activityAppScreen',
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_sleep = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 40,
                                    y: 340,
                                    w: 100,
                                    h: 100,
                                    radius: 50,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    click_func: button_widget => {
                                        router.launchApp({
                                            appId: router.SYSTEM_APP_SLEEP,
                                            native: true
                                        });
                                    },
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                });
                                Button_style = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                    x: 340,
                                    y: 340,
                                    w: 100,
                                    h: 100,
                                    radius: 50,
                                    press_src: img('transparent.png'),
                                    normal_src: img('transparent.png'),
                                    show_level: hmUI__namespace.show_level.ONLY_NORMAL,
                                    longpress_func: button_widget => {
                                        changeWatchFaceStyle();
                                    }
                                });
                                function secondUpdate() {
                                    const second = timeSensor.getSeconds();
                                    normal_time_second_text_font.setProperty(hmUI__namespace.prop.TEXT, second.toString().padStart(2, '0'));
                                }
                                ;
                                function minuteUpdate() {
                                    const minute = timeSensor.getMinutes();
                                    normal_time_minute_text_font.setProperty(hmUI__namespace.prop.TEXT, minute.toString().padStart(2, '0'));
                                    idle_time_minute_text_font.setProperty(hmUI__namespace.prop.TEXT, minute.toString().padStart(2, '0'));
                                }
                                ;
                                function hourUpdate() {
                                    const format_hour = timeSensor.getFormatHour();
                                    normal_time_hour_text_font.setProperty(hmUI__namespace.prop.TEXT, format_hour.toString().padStart(2, '0'));
                                    idle_time_hour_text_font.setProperty(hmUI__namespace.prop.TEXT, format_hour.toString().padStart(2, '0'));
                                    amPmUpdate();
                                }
                                ;
                                function amPmUpdate() {
                                    const hourFormat = timeSensor.getHourFormat();
                                    if (hourFormat == sensor.TIME_HOUR_FORMAT_12) {
                                        const am_pm = timeSensor.getHours() > 11 ? normal_PM_Text : normal_AM_Text;
                                        normal_AM_PM_text_font.setProperty(hmUI__namespace.prop.TEXT, am_pm);
                                        idle_AM_PM_text_font.setProperty(hmUI__namespace.prop.TEXT, am_pm);
                                    } else {
                                        normal_AM_PM_text_font.setProperty(hmUI__namespace.prop.TEXT, '');
                                        idle_AM_PM_text_font.setProperty(hmUI__namespace.prop.TEXT, '');
                                    }
                                }
                                ;
                                function dayUpdate() {
                                    const day = timeSensor.getDate();
                                    normal_day_text_font.setProperty(hmUI__namespace.prop.TEXT, day.toString().padStart(2, '0'));
                                    weekUpdate();
                                }
                                ;
                                function weekUpdate() {
                                    const week = timeSensor.getDay();
                                    normal_week_text_font.setProperty(hmUI__namespace.prop.TEXT, normal_WEEK_Array[week - 1]);
                                }
                                ;
                                function updateAllFonts() {
                                    secondUpdate();
                                    minuteUpdate();
                                    hourUpdate();
                                    dayUpdate();
                                    batteryIconFillUpdate();
                                }
                                ;
                                function batteryIconFillUpdate() {
                                    const valueBattery = battery.getCurrent();
                                    let progressBattery = valueBattery / 100;
                                    let originPositionY = 453;
                                    let height = -21 * progressBattery;
                                    if (progressBattery > 1)
                                        progressBattery = 1;
                                    if (height < 0) {
                                        height = -height;
                                        originPositionY = originPositionY - height;
                                    }
                                    normal_battery_linear_scale.setProperty(hmUI__namespace.prop.Y, originPositionY);
                                    normal_battery_linear_scale.setProperty(hmUI__namespace.prop.H, height);
                                }
                                ;
                                function useFontLanguageSize() {
                                    let textSizeConfig = {
                                        normal_battery_current_text_size: 40,
                                        normal_time_hour_text_size: 150,
                                        normal_time_minute_text_size: 150,
                                        normal_time_second_text_size: 50,
                                        normal_AM_PM_text_size: 42,
                                        normal_day_text_size: 40,
                                        normal_week_text_size: 40,
                                        idle_AM_PM_text_size: 42,
                                        idle_time_hour_text_size: 150,
                                        idle_time_minute_text_size: 150
                                    };
                                    switch (settings.getLanguage()) {
                                    case 0:
                                    case 1:
                                    case 5:
                                    case 11:
                                        textSizeConfig.normal_week_text_size = 24;
                                        textSizeConfig.normal_AM_PM_text_size = 26;
                                        textSizeConfig.idle_AM_PM_text_size = 26;
                                        break;
                                    default:
                                        break;
                                    }
                                    text_size_config = textSizeConfig;
                                }
                                ;
                                function useFontLanguage() {
                                    switch (settings.getLanguage()) {
                                    case 0:
                                    case 1:
                                    case 5:
                                    case 11:
                                        font_file_text = void 0;
                                        font_file_number = font('Courier Prime Sans.ttf');
                                        break;
                                    default:
                                        font_file_text = font('Courier Prime Sans.ttf');
                                        font_file_number = font('Courier Prime Sans.ttf');
                                        break;
                                    }
                                }
                                ;
                                function settingsLanguageConfig() {
                                    useFontLanguageSize();
                                    useFontLanguage();
                                    normal_WEEK_Array = [
                                        i18n.getText('week_mon'),
                                        i18n.getText('week_tue'),
                                        i18n.getText('week_wed'),
                                        i18n.getText('week_thu'),
                                        i18n.getText('week_fri'),
                                        i18n.getText('week_sat'),
                                        i18n.getText('week_sun')
                                    ];
                                    normal_AM_Text = i18n.getText('AM');
                                    normal_PM_Text = i18n.getText('PM');
                                }
                                ;
                                function changeWatchFaceStyle() {
                                    if (colorDialogWidgets.length) {
                                        closeColorDialog();
                                        return;
                                    }
                                    const colorDialogOverlay = hmUI__namespace.createWidget(hmUI__namespace.widget.CIRCLE, {
                                        center_x: 240,
                                        center_y: 240,
                                        radius: 240,
                                        color: 0,
                                        alpha: 200,
                                        show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                    });
                                    colorDialogWidgets.push(colorDialogOverlay);
                                    const btnSize = 60;
                                    const padding = 10;
                                    const columns = 6;
                                    const startX = 35;
                                    const startY = 105;
                                    colorPalette.forEach((color, idx) => {
                                        const colX = startX + idx % columns * (btnSize + padding);
                                        const colY = startY + Math.floor(idx / columns) * (btnSize + padding);
                                        const buttonFillColor = hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                            x: utils.px(colX),
                                            y: utils.px(colY),
                                            w: utils.px(btnSize),
                                            h: utils.px(btnSize),
                                            color,
                                            radius: 64,
                                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                                        });
                                        const buttonColor = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                            x: utils.px(colX),
                                            y: utils.px(colY),
                                            w: utils.px(btnSize),
                                            h: utils.px(btnSize),
                                            normal_src: img('transparent.png'),
                                            press_src: img('transparent.png'),
                                            show_level: hmUI__namespace.show_level.ONLY_NORMAL,
                                            click_func: () => {
                                                applyTextColorNumber(color);
                                                closeColorDialog();
                                            }
                                        });
                                        colorDialogWidgets.push(buttonFillColor, buttonColor);
                                    });
                                    const cancelBtn = hmUI__namespace.createWidget(hmUI__namespace.widget.BUTTON, {
                                        x: 160,
                                        y: 400,
                                        w: 160,
                                        h: 72,
                                        normal_src: img('transparent.png'),
                                        press_src: img('transparent.png'),
                                        font: font_file_text,
                                        show_level: hmUI__namespace.show_level.ONLY_NORMAL,
                                        click_func: () => closeColorDialog()
                                    });
                                    colorDialogWidgets.push(cancelBtn);
                                }
                                function closeColorDialog() {
                                    if (!colorDialogWidgets.length)
                                        return;
                                    try {
                                        colorDialogWidgets.forEach(widget => {
                                            try {
                                                hmUI__namespace.deleteWidget(widget);
                                            } catch (e) {
                                            }
                                        });
                                    } catch (e) {
                                        logger.log('Error deleting dialog widgets', e);
                                    }
                                    colorDialogWidgets = [];
                                }
                                function applyTextColorNumber(color) {
                                    selectedTextColor = color;
                                    const widgetsToUpdate = [
                                        normal_time_minute_text_font,
                                        idle_time_minute_text_font,
                                        normal_AM_PM_text_font,
                                        idle_AM_PM_text_font,
                                        normal_day_text_font,
                                        normal_battery_linear_scale,
                                        normal_battery_icon_img_top,
                                        normal_battery_icon_img_out
                                    ];
                                    widgetsToUpdate.forEach(widget => {
                                        widget.setProperty(hmUI__namespace.prop.COLOR, color);
                                    });
                                }
                                const widgetDelegate = hmUI__namespace.createWidget(hmUI__namespace.widget.WIDGET_DELEGATE, {
                                    resume_call: function () {
                                        updateAllFonts();
                                        const screenType = app.getScene();
                                        if (screenType == app.SCENE_WATCHFACE || screenType == app.SCENE_AOD) {
                                            if (!timerId) {
                                                if (useTimer) {
                                                    timerId = timer.createTimer(0, 1000, secondUpdate, {});
                                                } else if (useInterval) {
                                                    timerId = setInterval(secondUpdate, 1000);
                                                } else {
                                                    logger.log('No timer available!');
                                                }
                                            }
                                        }
                                    },
                                    pause_call: function () {
                                        if (timerId) {
                                            if (useTimer)
                                                timer.stopTimer(timerId);
                                            if (useInterval)
                                                clearInterval(timerId);
                                            timerId = null;
                                        }
                                    }
                                });
                                updateAllFonts();
                            },
                            onInit() {
                                if (typeof timer !== 'undefined' && typeof timer.createTimer == 'function') {
                                    useTimer = true;
                                } else if (typeof setInterval == 'function') {
                                    useInterval = true;
                                } else {
                                    logger.log('No timer available!');
                                }
                            },
                            build() {
                                this.init_view();
                                logger.log('index page.js on ready invoke');
                            },
                            onDestroy() {
                                if (timerId) {
                                    if (useInterval)
                                        clearInterval(timerId);
                                    else
                                        timer.stopTimer(timerId);
                                    timerId = null;
                                }
                                logger.log('index page.js on destroy invoke');
                            }
                        });
                    })());
                } catch (e) {
                    console.log('Watchface Error', e);
                    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
                }
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}