console.log('current filepath: /app.js');
try {
    ((() => {
        const {beforeAppCreate = () => {
            }, afterAppCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeAppCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const logger = utils.log.getLogger('app');
                __$$app$$__.app = App({
                    globalData: {},
                    onCreate() {
                        logger.log('app on create invoke');
                    },
                    onDestroy() {
                        logger.log('app on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterAppCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}